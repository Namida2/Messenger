package com.example.messenger.fragments;public class MessengerFragment {
}
