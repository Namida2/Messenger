package tools;

public class Const {
    public static final String TAG = "MyLogTag";

    public class CollectionUsers {
        public static final String COLLECTION_USERS = "users";
    }

}
